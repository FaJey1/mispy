import logging
import time
import os
import csv

from yaspin import yaspin
from yaspin.spinners import Spinners

from mispy.extract_mesh import *
from mispy.transform_mesh import *
from mispy.visualization_mesh import *

import pandas as pd
import matplotlib.pyplot as plt
from io import StringIO


logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")


def measure_time(func, *args, **kwargs):
    """
    Измеряет время выполнения функции.
    
    Параметры:
        func: callable — функция для вызова
        *args, **kwargs — аргументы для функции
    
    Возвращает:
        tuple(result, elapsed_time)
    """
    start = time.time()
    result = func(*args, **kwargs)
    elapsed = time.time() - start
    return result, elapsed


# def alg(mesh: Mesh, split_func: str = "sah", esc_enable: bool = False, draw_aabb: bool = False, edge_enable: bool = False, faces_enable: bool = True, faces_to_fix_enable: bool = False, faces_in_node = 1):
#     times = {}
#     bvh = BVHTree(mesh, faces_in_node=1)
#     # --- prepare_mesh ---
#     with yaspin(Spinners.arc, text="Подготовка сетки...") as sp:
#         _, times["Время подготовки сетки"] = measure_time(bvh.prepare_mesh, esc_enable=False)
#         sp.ok("DONE")

#     # --- build_tree ---
#     with yaspin(Spinners.arc, text=f"Построение BVH (split={split_func})...") as sp:
#         _, times["Время построения дерева"] = measure_time(bvh.build_tree, split_func=split_func)
#         sp.ok("DONE")

#     # --- traversal ---
#     with yaspin(Spinners.arc, text="Трассировка BVH...") as sp:
#         candidate_pairs, times["Время обхода дерева"] = measure_time(bvh.traversal_tree)
#         faces_to_fix = bvh.faces_to_fix
#         sp.ok("DONE")
        
#     # --- triangulation ---
#     # with yaspin(Spinners.arc, text="Триангуляция 'сломанных' ячеек...") as sp:
#     #     times["Время триангуляции"] = measure_time()
#     #     sp.ok("DONE")

#     # --- build graph
#     graph = bvh.build_graph(bvh.root_node)
    
#     # --- Вывод результатов ---
#     table = [
#         ["Функция разбиения", split_func],
#         ["Количество ячеек в листе", faces_in_node],
#         ["Использование раннего разбиения", esc_enable],
#         ["Найдено пар ячеек для коррекции", len(faces_to_fix)],
#     ]
#     for name, t in times.items():
#         table.append([name, f"{t:.6f} сек"])

#     logging.info("=== Результаты BVH алгоритма ===\n%s\n%s\n%s", 
#                  tabulate(
#                     table,
#                     headers=["Параметр", "Значение"],
#                     tablefmt="grid"
#                 ),
#                 statistic_bvh_tree_graph(graph),
#                 statistic_mesh(mesh))
    
    #mesh_plotter(mesh=mesh, faces_enable=faces_enable, draw_aabb=draw_aabb, edge_enable=edge_enable, faces_to_fix = faces_to_fix, faces_to_fix_enable=faces_to_fix_enable)
    #fix_face_plotter(mesh=mesh, faces_to_fix=faces_to_fix, stop_draw=1)
    
    #pairs_broken_face_plotter(candidate_pairs, stop_draw=1)
    #pairs_plotter([(mesh.find_face_by_id(4838), mesh.find_face_by_id(4841))])

def build_table_1(results):
    return [
        {
            "Тест": r["test_id"],
            "Сетка": r["mesh"],

            "Время подготовки, сек": r["prepare_time"],
            "Время построения, сек": r["build_time"],

            "Вершин BVH": r["bvh_vertices"],
            "Рёбер BVH": r["bvh_edges"],
            "Глубина BVH": r["bvh_depth"],
            "Сбалансированность BVH (std)": f"{r['bvh_balance']:.2f}",

            "Кол-во ячеек": r["faces"],
            "Кол-во ребер": r["edges"],
            "Кол-во вершин": r["nodes"],
            
            "ESC": r["esc"],
            "Ячеек в листе": r["faces_in_node"],
        }
        for r in results
    ]


def build_table_2(results):
    return [
        {
            "Тест": r["test_id"],
            "Сетка": r["mesh"],
            "Кол-во ячеек": r["faces"],
            "Кол-во ребер": r["edges"],
            "Кол-во вершин": r["nodes"],
            "Время обхода, сек": r["traversal_time"],
            "Найдено пар ячеек для коррекции": r["pairs_to_fix"],
            "ESC": r["esc"],
            "Разбиение": r["split_func"],
            "Ячеек в листе": r["faces_in_node"],
        }
        for r in results
    ]


def build_table_3(results):
    return [
        {
            "Тест": r["test_id"],
            "Сетка": r["mesh"],

            "Общее время, сек": r["total_time"],
            "Подготовка, сек": r["prepare_time"],
            "Построение, сек": r["build_time"],
            "Обход, сек": r["traversal_time"],

            "Ячеек": r["faces"],
            "Рёбер": r["edges"],
            "Вершин": r["nodes"],

            "Пар для коррекции": r["pairs_to_fix"],

            "ESC": r["esc"],
            "Функция разбиения": r["split_func"],
            "Ячеек в листе": r["faces_in_node"],
        }
        for r in results
    ]
  

def save_csv(filename, rows):
    os.makedirs("results", exist_ok=True)
    path = os.path.join("results", filename)

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    

def visualization_results():
    df = pd.read_csv("results/table3_summary-2.csv")

    colors = {
        "prepare": "#FFA94D",    # светло-оранжевый
        "build": "#5B8DB8",      # серо-голубой
        "traversal": "#7C6AB9",  # серо-фиолетовый
    }

    grids = df["Сетка"].unique()

    for grid in grids:
        # Фильтруем по сетке и сортируем по общему времени
        df_grid = df[df["Сетка"] == grid].sort_values("Общее время, сек")

        tests = [f"Тест {int(t)}\nESC:{e}\nSF:{sf}\nFoL:{fol}\nCF: {cf}" 
                 for t,e,sf,fol,cf in zip(df_grid["Тест"], df_grid["ESC"], df_grid["Функция разбиения"], df_grid["Ячеек в листе"], df_grid["Пар для коррекции"])]
        prepare = df_grid["Подготовка, сек"]
        build = df_grid["Построение, сек"]
        traversal = df_grid["Обход, сек"]
        total_time = df_grid["Общее время, сек"]

        plt.figure(figsize=(12, 6))
        plt.bar(tests, prepare, label="Время подготовки", color=colors["prepare"])
        plt.bar(tests, build, bottom=prepare, label="Время построения", color=colors["build"])
        plt.bar(tests, traversal, bottom=prepare + build, label="Время обхода", color=colors["traversal"])

        # Добавляем пунктирные линии и подписи времени
        for i, t in enumerate(total_time):
            plt.hlines(y=t, xmin=i-0.4, xmax=i+0.4, colors='gray', linestyles='dashed', linewidth=1)
            plt.text(i, t + 0.001, f"{t:.4f}", ha='center', va='bottom', fontsize=8, color='gray')

        plt.ylabel("Время выполнения, сек")
        plt.xlabel("Тесты")
        plt.title(f"Время выполнения BVH по этапам для сетки '{grid}'")
        plt.legend()
        plt.xticks(rotation=45, ha="right")
        plt.tight_layout()
        plt.show()


def alg(
    mesh: Mesh,
    test_id: int,
    split_func: str = "sah",
    esc_enable: bool = False,
    draw_aabb: bool = False,
    edge_enable: bool = False,
    faces_enable: bool = True,
    faces_to_fix_enable: bool = False,
    faces_in_node: int = 1):
    times = {}

    bvh = BVHTree(mesh, faces_in_node=faces_in_node)

    # --- prepare_mesh ---
    _, times["prepare"] = measure_time(
        bvh.prepare_mesh, esc_enable=esc_enable
    )

    # --- build_tree ---
    _, times["build"] = measure_time(
        bvh.build_tree, split_func=split_func
    )

    # --- traversal ---
    candidate_pairs, times["traversal"] = measure_time(
        bvh.traversal_tree
    )

    #--- build graph
    graph = bvh.build_graph(bvh.root_node)
    
    faces_to_fix = bvh.faces_to_fix

    # --- Вывод результатов ---
    bvh_table, bvh_stats = statistic_bvh_tree_graph(graph)
    mesh_table, mesh_stats = statistic_mesh(mesh)
    
    table = [
        ["Функция разбиения", split_func],
        ["Количество ячеек в листе", faces_in_node],
        ["Использование раннего разбиения", esc_enable],
        ["Найдено пар ячеек для коррекции", len(faces_to_fix)],
    ]
    for name, t in times.items():
        table.append([name, f"{t:.6f} сек"])

    logging.info("=== Результаты BVH алгоритма ===\n%s\n%s\n%s", 
                 tabulate(
                    table,
                    headers=["Параметр", "Значение"],
                    tablefmt="grid"
                ),
                bvh_table,
                mesh_table)
    
    total_time = (
        times["prepare"] +
        times["build"] +
        times["traversal"]
    )

    # --- Сериализация результата ---
    result = {
        "test_id": test_id,
        "mesh": mesh.title,

        # --- геометрия сетки ---
        "faces": mesh_stats["faces"],
        "edges": mesh_stats["edges"],
        "nodes": mesh_stats["nodes"],

        # --- время ---
        "prepare_time": times["prepare"],
        "build_time": times["build"],
        "traversal_time": times["traversal"],
        "total_time": total_time,

        # --- параметры эксперимента ---
        "split_func": split_func.upper(),
        "esc": esc_enable,
        "faces_in_node": faces_in_node,

        # --- коррекция ---
        "pairs_to_fix": len(faces_to_fix),

        # --- структура BVH ---
        "bvh_vertices": bvh_stats["bvh_nodes"],
        "bvh_edges": bvh_stats["bvh_edges"],
        "bvh_depth": bvh_stats["bvh_depth"],
        "bvh_balance": bvh_stats["bvh_balance"],
    }

    return result   
    

def main():
    mesh1 = Mesh("tests/examples/small_sphere_double.dat")
    mesh2 = Mesh("tests/examples/sphere_double.dat")
    mesh3 = Mesh("tests/examples/bunny_double.dat")
    #mesh = Mesh("tests/examples/air_inlet_010000000000.dat")
    tests = {
        19: [
            mesh1, True, "sah", 5],
        20: [
            mesh2, True, "sah", 5],
        21: [
            mesh3, True, "sah", 5],
        22: [
            mesh1, True, "sah", 1],
        23: [
            mesh2, True, "sah", 1],
        24: [
            mesh3, True, "sah", 1],
        1: [
            mesh1, False, "vah", 5],
        2: [
            mesh2, False, "vah", 5],
        3: [
            mesh3, False, "vah", 5],
        4: [
            mesh1, False, "vah", 1],
        5: [
            mesh2, False, "vah", 1],
        6: [
            mesh3, False, "vah", 1],
        7: [
            mesh1, False, "sah", 5],
        8: [
            mesh2, False, "sah", 5],
        9: [
            mesh3, False, "sah", 5],
        13: [
            mesh1, True, "vah", 5],
        14: [
            mesh2, True, "vah", 5],
        15: [
            mesh3, True, "vah", 5],
        16: [
            mesh1, True, "vah", 1],
        17: [
            mesh2, True, "vah", 1],
        18: [
            mesh3, True, "vah", 1],
        10: [
            mesh1, False, "sah", 1],
        11: [
            mesh2, False, "sah", 1],
        12: [
            mesh3, False, "sah", 1],
    }
    
    results = []
    # for key in tests:
    #     logging.info("=== ТЕСТ %s, СЕТКА %s ===", key, tests[key][0].title)
    #     result = alg(mesh = tests[key][0], test_id = key, faces_enable = True, draw_aabb = False, esc_enable = tests[key][1], edge_enable = True, faces_to_fix_enable = True, split_func = tests[key][2], faces_in_node = tests[key][3] )
    #     results.append(result)

    for test_id, (mesh, esc, split, leaf) in tests.items():
        logging.info("=== ТЕСТ %d, СЕТКА %s ===", test_id, mesh.title)
        result = alg(
            mesh=mesh,
            test_id=test_id,
            esc_enable=esc,
            split_func=split,
            faces_in_node=leaf
        )
        results.append(result)

    save_csv("table1_prepare_build.csv", build_table_1(results))
    save_csv("table2_traversal.csv", build_table_2(results))
    save_csv("table3_summary.csv", build_table_3(results))
    
    #alg(mesh = mesh1, faces_enable = True, draw_aabb = False, esc_enable = False, edge_enable = True, faces_to_fix_enable = True, split_func = "vah", faces_in_node = 5 )


if __name__ == '__main__':
    main()
    visualization_results()
