import logging
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional, Literal
from collections import defaultdict

import numpy as np
import networkx as nx

from mispy.extract_mesh import Mesh, Zone, Face, Edge, Node
from .czech_classify import CzechClassify


logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")


@dataclass
class BVHNode:
    """
    Узел BVH‑дерева.
    """

    node_id: int
    bounding_box: Tuple[np.ndarray, np.ndarray]
    is_leaf: bool
    faces: List[Face] = field(default_factory=list)
    children: Tuple[Optional["BVHNode"], Optional["BVHNode"]] = (None, None)
    
@dataclass
class PrimitiveRef:
    """
    Обёртка над гранью и её AABB, чтобы каждый раз не пересчитывать bbox.
    """

    face: Face
    bb_min: np.ndarray
    bb_max: np.ndarray
    

def _aabb_empty() -> Tuple[np.ndarray, np.ndarray]:
    """Пустой AABB."""
    bb_min = np.array([np.inf, np.inf, np.inf], dtype=float)
    bb_max = np.array([-np.inf, -np.inf, -np.inf], dtype=float)
    return bb_min, bb_max


def _aabb_include(
    bb_min: np.ndarray, bb_max: np.ndarray, other_min: np.ndarray, other_max: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """Расширяет AABB текущим боксом и возвращает новый (min, max)."""
    return np.minimum(bb_min, other_min), np.maximum(bb_max, other_max)


def _aabb_surface_area(bb_min: np.ndarray, bb_max: np.ndarray) -> float:
    d = np.maximum(bb_max - bb_min, 0.0)
    return 2.0 * (d[0] * d[1] + d[1] * d[2] + d[0] * d[2])


def _aabb_volume(bb_min: np.ndarray, bb_max: np.ndarray) -> float:
    d = np.maximum(bb_max - bb_min, 0.0)
    return float(d[0] * d[1] * d[2])

def _aabb_intersect(a_min, a_max, b_min, b_max):
    return np.all((a_min <= b_max) & (a_max >= b_min))


class BVHTree:
    """
    BVH‑дерево для поиска потенциально пересекающихся пар треугольников.

    Строится по описанному алгоритму:
    - на каждом уровне есть 3 списка примитивов, отсортированных по vmax AABB
      по осям X, Y, Z;
    - для каждой оси делается двухпроходный "sweep" (справа‑налево и слева‑направо)
      для оценки всех разбиений с помощью SAH или VAH;
    - выбирается лучшее разбиение, после чего списки переупорядочиваются и
      рекурсивно строятся дочерние узлы.
    """

    SAH_OVERSPLIT_THRESHOLD: float = 1.0
    EMPTY_NODE_TRAVERSAL_COST: float = 1.0

    def __init__(self, mesh: Mesh, faces_in_node: int = 1):
        self.mesh: Mesh = mesh
        # Сколько граней максиму может содержаться в ячейке
        self.faces_in_node: int = max(1, int(faces_in_node))

        self.nodes_counter: int = 0
        self.nodes: List[BVHNode] = []
        self.root_node: Optional[BVHNode] = None

        # Для последующей геометрической проверки (если понадобится)
        self.faces_to_fix: Dict[int, List] = defaultdict(list)

        # Подготовленные примитивы (заполняются в prepare_mesh)
        self._primitives: List[PrimitiveRef] = []
        self._mesh_bb_min: Optional[np.ndarray] = None
        self._mesh_bb_max: Optional[np.ndarray] = None
        
    # ----------------------------------------------------------------------------------

    def prepare_mesh(self, esc_enable: bool = False) -> None:
        """
        Предварительная подготовка: для каждой грани считаем AABB и
        запоминаем их в списке примитивов.

        Параметр esc_enable зарезервирован под возможные эвристики
        "раннего останова/разбиения". Сейчас он влияет только на логирование.
        """

        logging.info(
            "BVH: prepare_mesh started (ESC enabled: %s), faces=%d",
            esc_enable,
            len(self.mesh.faces),
        )

        self._primitives.clear()
        mesh_bb_min, mesh_bb_max = _aabb_empty()

        for face in self.mesh.faces:
            coords = np.array([node.p for node in face.nodes], dtype=float)
            bb_min = coords.min(axis=0)
            bb_max = coords.max(axis=0)

            self._primitives.append(PrimitiveRef(face=face, bb_min=bb_min, bb_max=bb_max))
            mesh_bb_min, mesh_bb_max = _aabb_include(mesh_bb_min, mesh_bb_max, bb_min, bb_max)

        self._mesh_bb_min = mesh_bb_min
        self._mesh_bb_max = mesh_bb_max

        logging.info(
            "BVH: prepare_mesh finished; primitives=%d, mesh_bb_min=%s, mesh_bb_max=%s",
            len(self._primitives),
            self._mesh_bb_min,
            self._mesh_bb_max,
        )