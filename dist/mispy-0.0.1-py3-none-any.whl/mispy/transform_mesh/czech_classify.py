import logging

import numpy as np
from typing import List, Tuple


logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

class CzechClassify:
    def __init__(self, candidates: Tuple, checked_pairs=None):
        # пары, которые могут пересекаться
        self.face1, self.face2 = candidates
        self.impossible_couples = []
        self.points = []
        self.checked_pairs = checked_pairs if checked_pairs is not None else set()
        self.impossible_cases = {"001", "002", "012", "122", "222"}
        self.case000 = "000"
