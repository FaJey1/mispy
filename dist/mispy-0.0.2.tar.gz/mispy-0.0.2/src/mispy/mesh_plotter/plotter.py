from mispy.extract_mesh import Mesh, Zone, Face, Edge, Node

def mesh_plotter(mesh):
    print(type(mesh.nodes))

# ==================================================================================================

if __name__ == '__main__':
    mesh = Mesh("tests/examples/small_sphere_double.dat")
    mesh_plotter(mesh)

# ==================================================================================================